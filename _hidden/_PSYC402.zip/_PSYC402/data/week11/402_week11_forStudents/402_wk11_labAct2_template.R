# PSYC402: Week 11 - Lab activity 2

# Step 1: Background and set up -------------------------------------------

# Empty R environment

# Load relevant libraries

# Read in the data

# Have a look at the data

# Step 2: Restructuring the ratings data ----------------------------------


# Step 3: Calculate mean trustworthiness rating for each voice ------------


# Step 4: Join the data together -----------------------------------------


# Step 5: Spreading the data ----------------------------------------------


# Step 6: Visualising the data --------------------------------------------


# Step 7: Conducting and interpreting simple regression -----------------------


# Step 8: Conducting and interpreting multiple regression -----------------


# Step 9: Checking assumptions --------------------------------------------


# Step 10: Writing up the results -----------------------------------------

